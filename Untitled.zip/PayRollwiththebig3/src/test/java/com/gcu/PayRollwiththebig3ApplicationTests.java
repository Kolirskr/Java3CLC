package com.gcu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PayRollwiththebig3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
